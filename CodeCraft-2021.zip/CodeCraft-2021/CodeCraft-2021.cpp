#include <iostream>
#include "Solution.h"
using namespace std;

int main() {
    // TODO:read standard input
    // TODO:process
    // TODO:write standard output
    // TODO:fflush(stdout);

    string txtPath = "training-2.txt";
    //Solution solution(txtPath);
    Solution solution;
    solution.run();
    return 0;
}



